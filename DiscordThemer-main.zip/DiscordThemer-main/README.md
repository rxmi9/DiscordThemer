# DiscordThemer
Xposed module that allows you to change colors in Discord. Requires enabled Resource Hooks in EdXposed / LSPosed Manager settings.

**Note**: This app doesn't support Android below version 6.0, on lower versions may crash or just not work.

If you don't use [LSPosed](https://github.com/LSPosed/LSPosed) you may need to reboot to see all your changes.

[Support Server](https://discord.gg/EsNDvBaHVU)

### TODO
- Rewrite module to kotlin and ui to jetpack compose
- Updater
- More fixes for latests versions
- Revert rebrand theme
- Update descriptions for advanced mode to match latest version of Discord
- Customize more things than colors

### Screenshots
<img src="assets/Screenshot_1.png" height="400"></img>
<img src="assets/Screenshot_2.png" height="400"></img>
<img src="assets/Screenshot_3.png" height="400"></img>
